from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql.functions import lit
import numpy as np
import pyspark.sql.functions as sqlfunc

spark = SparkSession.builder.appName("Read CSV").getOrCreate()

df = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load("path/to/csv/file.csv")

mydata.shaow()

mydata2 = mydata.withColumn("clean_city" , when(mydata.city.isNull(), 'Unknown').otherwise(mydata.city))

mydata2.show()

mydata2 = mydata2.filter (mydata2.jobtitle.isNotnull())

mydata2.show()

mydata2 = mydatat2.withColumn('Clean_salary',mydata2.salary.substr(2,100.cast('float;))

mydata2.show()
mean = mydatta2.groupBy().avg(clean_salary'.take(1)[0][0]

print(mean)

mydata2 = mydata2.withColumn('New_salary', when(mydata2.clean_salary.isNull(),lit(mean)).otherrwise(mydata2.clean_salary))

mydata2.show()

latitudes = mydata2.select('Latitude')

latitudes.show()

latitudes = latitudes.filter(latitudes.Latitude.isNotNull())

latutudes.show()

lattitudes = latitudes.WithColumn('latutude2', latitudes.LAtutude.cast('float')).select('latutude2')

Latitudes.show()

median = np.median(latitudes.collect())

Print(median)

mydata2 = mydata2.withColumn('col',when(mydatat2.Latitude.isNull(),lit(median)).otherwise(mydata2.Latiyude))

mydata2.show()

genders = mydata2.groupby('gender').agg(sqlfun.avg('new_salary').alis('Avgsalary'))

gender.show()

df=mydata2.withcolumn('female_salary', when(mydata2.gender=='female',mydata2.new salary).otherwise(lit(0)))

df.show()

df=df.withcolumn('male_salary', when(df.gender=='male',df.new salary).otherwise(lit(0)))

df.show()

df= df.groupby('jobTitle').agg(sqlfun.avg('femael_salary').alis('final_female_salary'), sqlfun.avg('male_salary').alias('final_male_slalry;))

df.show()
